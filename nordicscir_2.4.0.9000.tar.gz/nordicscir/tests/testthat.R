library(testthat)
library(nordicscir)

test_check("nordicscir")
